import React from 'react';
import './App.css';

const Home = () => {
    return (
        <div className="home-container">
            <h2>Welcome to the Home Page</h2>
        </div>
    );
};

export default Home;

